# Open Source Barware SEO Submission Packages

Date: 2026-07-08
Project: opensourcebarware
Site: https://opensourcebarware.com
Repo: https://github.com/RichardBJamison/open-source-barware

## BLUF

IndexNow was re-run and returned 200 OK from both `api.indexnow.org` and `bing.com`. The live sitemap returns 200 and includes the home page, `/the-process`, `/free-bar-inventory-software`, `/blog`, and all 4 new 2026-07-08 blog posts. RestaurantIMS was submitted successfully and is now in editor review.

Local SEO cleanup also completed:
- `public/llms.txt`: removed stale Agave & Rye reference.
- `app/open-source-compliance/page.tsx`: fixed GitHub username typo.
- `public/downloads/SOURCE-OFFER.md`: fixed GitHub username typo.

These local fixes need the next deploy before they are live.

## Core Submission Copy

### Product Name
Open Source Barware

### Short Tagline
Free, open-source bar inventory system built for real bar workflows.

### Short Description
Open Source Barware is a free, GPLv3 bar inventory system for bars and restaurants: voice or walk-based counting, tenths, scale-ready precision, POS imports, variance, recipe costing, smart orders, receiving, par alerts, mobile counting, and multi-venue support. No subscription, no account, no cloud lock-in.

### Long Description
Open Source Barware is a free, open-source bar inventory system built by a bartender/operator for the way real bars count. It starts simple: walk the bar, use voice notes or typed entry, count bottles by tenths, and get a clean weekly process without renting another SaaS tool. When an operation needs more precision, it scales into industrial-strength workflows: scale-ready bottle measurements, POS import from Toast, Square, or CSV, variance by bottle, station, shift, and category, recipe costing, smart orders, receiving, par alerts, barcode scanning, mobile counting, and multi-venue support. It runs locally on your laptop, keeps data in open formats, and requires no subscription, account, or cloud lock-in.

### Categories
Inventory Management; Bar & Beverage; Restaurant Management; Recipe Costing; Procurement / Ordering; Analytics / Reporting; Open Source; Self-hosted / Local Software.

### Tags / Keywords
free bar inventory system, free inventory system, bar inventory software, open source bar inventory, liquor inventory, beverage inventory, restaurant inventory, POS integration, Toast, Square, variance tracking, recipe costing, smart orders, GPLv3.

### Primary URLs To Use
- Homepage: https://opensourcebarware.com/
- Primary keyword landing page: https://opensourcebarware.com/free-bar-inventory-software
- Process / feature story: https://opensourcebarware.com/the-process
- Download: https://opensourcebarware.com/download
- Program guide: https://opensourcebarware.com/downloads
- Compliance/source: https://opensourcebarware.com/open-source-compliance
- Blog hub: https://opensourcebarware.com/blog
- Setup guide: https://opensourcebarware.com/blog/free-inventory-system-guide
- Best free system article: https://opensourcebarware.com/blog/best-free-bar-inventory-system
- Variance article: https://opensourcebarware.com/blog/variance-tracking-that-works
- POS article: https://opensourcebarware.com/blog/pos-integration-free-inventory
- RSS: https://opensourcebarware.com/blog/feed.xml
- Logo: https://opensourcebarware.com/images/logo.png
- OG image: https://opensourcebarware.com/images/og-image.jpg

## Phase 1: This Week

| Target | Category | URL / Process | Status | URL To Submit | Why It Helps |
| --- | --- | --- | --- | --- | --- |
| Google Search Console | Search engines | Submit sitemap, then URL Inspection > Request Indexing | Human action required | sitemap + `/the-process`, `/free-bar-inventory-software`, `/blog`, 4 posts | Fastest Google discovery path for new pages and refreshed keyword landing pages. |
| Bing Webmaster Tools | Search engines | Submit sitemap + individual URL submission | Human action required; IndexNow already 200 OK | same as GSC | Bing + Copilot visibility; IndexNow already helps. |
| RestaurantIMS | Bar/hospitality niche | https://restaurantinventorymanagementsoftware.com/submit | Submitted; editor review | `/free-bar-inventory-software` | Direct niche relevance; has Inventory and Bar & Beverage categories; free merit-ranked listing. |
| FSF Free Software Directory | Open-source communities | Create FSF account, then https://directory.fsf.org/wiki/Form:Entry or join Friday IRC | Copy ready | `/open-source-compliance`, repo, download | Best authority match for GPLv3/free software; high trust, license-reviewed. |
| SourceForge Open Source Project | Software/product directories | https://sourceforge.net/create/ > Create Your Project Now or Import from GitHub | Copy ready; account required | repo + `/download` | Open-source download/discovery authority, project mirrors, reviews, and directory categories. |
| AlternativeTo | Software/product directories | Sign in > user icon > Suggest new application | Copy ready; account required | `/free-bar-inventory-software` | Captures “alternatives to WISK/BevSpot/Partender/Backbar” search intent. |
| OpenSourceAlternative.to | Open-source directories | https://www.opensourcealternative.to/submit | Copy ready; has free waitlist or paid 48-hour option | repo + homepage | Strong “open-source alternative to proprietary software” fit. |

## Phase 2: Next

| Target | Category | URL / Process | Status | URL To Submit | Why It Helps |
| --- | --- | --- | --- | --- | --- |
| OpenAlternative | Open-source directories | https://openalternative.co/submit, login required | Copy ready | repo + homepage | Curated OSS alternative directory with self-hosted/open-source discovery traffic. |
| SaaSHub | General software directories | https://www.saashub.com/submit/list | Copy ready; account likely required | `/free-bar-inventory-software` | Inventory category exists; good alternative-comparison SEO. |
| G2 | Social/proof + software reviews | https://sell.g2.com/create-a-profile | Copy ready; product profile request | homepage + `/free-bar-inventory-software` | High-trust review/profile source often surfaced in AI and SERP software comparisons. |
| Capterra / GetApp / Software Advice | Software/product directories | Use vendor/listing request via G2 Digital Markets / Software Advice vendor flow | Copy ready; may require vendor intake | homepage + `/free-bar-inventory-software` | High-authority software buyer surfaces. Best after 2-3 real operator reviews are ready. |
| Product Hunt | Social/proof sites | https://www.producthunt.com/launch > Submit > New Product | Prep first, then launch | homepage or `/download` | Launch traffic/social proof. Needs assets and founder comment, not a rushed listing. |
| Hacker News Show HN | Social/proof communities | https://news.ycombinator.com/showhn.html | Draft ready; submit when founder can reply | homepage or `/download` | Good technical/open-source audience; no signup wall is a strong fit. |

## Phase 3: Ongoing

| Target | Category | URL / Process | Status | URL To Submit | Why It Helps |
| --- | --- | --- | --- | --- | --- |
| awesome-selfhosted | Open-source communities | PR to https://github.com/awesome-selfhosted/awesome-selfhosted | Only if the app is clearly self-hostable/server-hostable | repo | Huge OSS authority, but acceptance depends on fit. Current local/laptop Chrome-side app may be borderline. |
| Launching Next | General directories | https://www.launchingnext.com/submit/ | Copy ready | homepage | Lightweight startup listing; decent if no fee. |
| BetaList | General directories | https://betalist.com/submit | Lower priority; may be paid/no free tier | homepage | Only if positioning as new tech startup launch; not as strong as niche/operator sites. |
| Indie Hackers | Social/proof sites | Founder story post; do not spam | Draft angle ready | `/blog/best-free-bar-inventory-system` | Good founder/operator story channel; best as narrative post, not directory spam. |
| r/BarOwners / r/bartenders | Bar/hospitality niche | Community post only if rules allow; ask for feedback, not promotion | Draft angle ready | `/blog/free-inventory-system-guide` | Targeted operator feedback and real language. Avoid promotional posting. |
| USBG local/state chapters | Backlink opportunities | Direct outreach to resource/newsletter contacts | Email ready | `/resources` or `/free-bar-inventory-software` | Relevant trade authority; strongest when positioned as a free resource for bartenders. |
| Hospitality Upgrade vendor profile | Hospitality niche | https://www.hospitalityupgrade.com/vendor | Lower priority; likely paid/vendor profile | homepage | Hospitality tech authority, more hotel-oriented. |
| State restaurant/hospitality association vendor directories | Bar/hospitality niche | Start with Ohio, Washington, Florida, Texas associations | Evaluate fees/membership | homepage | High local/regional authority when fee is reasonable and listing is editorially legit. |

## Ready-To-Use Top Submission Blocks

### 1. FSF Free Software Directory

Process:
1. Create/log into FSF Central Login.
2. Use `https://directory.fsf.org/wiki/Form:Entry`.
3. If blocked, join Friday IRC meeting in `#fsf` on Libera.Chat or email `directory-discuss@gnu.org`.

Package:
- Name: Open Source Barware
- Short description: Free GPLv3 bar inventory system for real bar workflows.
- Full description: Open Source Barware is a GPLv3 bar inventory system for bars and restaurants. It runs locally, keeps data in open formats, and has no subscription, account, or cloud lock-in. Operators can count by walking the bar, using voice notes or typed entry, tenths counting, and scale-ready precision. It also supports POS imports from Toast, Square, and CSV; variance by bottle, station, shift, and category; recipe costing; smart orders; receiving; par alerts; mobile counting; barcode scanning; and multi-venue workflows.
- License: GNU General Public License v3.0 or later
- Homepage: https://opensourcebarware.com/
- Source code: https://github.com/RichardBJamison/open-source-barware
- Download: https://opensourcebarware.com/download
- Compliance: https://opensourcebarware.com/open-source-compliance
- Categories: Business, Inventory, Restaurant, Bar, Productivity
- Keywords: free software, GPLv3, inventory, bar inventory, restaurant inventory, beverage inventory, open source
- Contact: rbjpholdings@gmail.com

### 2. SourceForge Open Source Project

Process:
1. Go to `https://sourceforge.net/create/`.
2. Choose Create Project or Import from GitHub.
3. Use the repo URL and public download packages.

Package:
- Project name: Open Source Barware
- Unix/project slug: open-source-barware
- Summary: Free, GPLv3 bar inventory system built for real bar workflows.
- Description: Open Source Barware is a free and open-source bar inventory system for hospitality teams. It is designed for the real count: walk the bar, use voice or typed input, count bottles by tenths, reconcile with POS data, and understand variance by bottle, station, shift, and category. The system runs locally, keeps data in open formats, and has no subscription, account, or cloud lock-in. It includes POS import support for Toast, Square, and CSV; smart orders; receiving; recipe costing; par alerts; barcode scanning; mobile counting; and multi-venue support.
- Categories: Business, Inventory Management, Point of Sale, Restaurants, Spreadsheets
- License: GPLv3 or later
- Operating systems: Windows, macOS, Chrome/Browser
- Programming languages / tech: TypeScript, Next.js, Python/Flask, JavaScript
- Homepage: https://opensourcebarware.com/
- Download URL: https://opensourcebarware.com/download
- Source URL: https://github.com/RichardBJamison/open-source-barware

### 3. AlternativeTo

Process:
1. Log into `https://alternativeto.net/`.
2. User icon > Suggest new application.
3. Add Open Source Barware as an alternative to WISK, BevSpot, Partender, Backbar, Craftable, and MarketMan where allowed.

Package:
- Application name: Open Source Barware
- Website: https://opensourcebarware.com/free-bar-inventory-software
- Source code: https://github.com/RichardBJamison/open-source-barware
- License: Open Source / GPLv3
- Platforms: Web, Windows, macOS, Chrome
- Short description: Free open-source bar inventory system with local counts, POS import, variance, recipes, orders, receiving, and multi-venue support.
- Long description: Open Source Barware is a free bar inventory system for operators who do not want another subscription or locked cloud account. It starts with simple real-world counting: walk the bar, use voice notes or typed entry, count by tenths, and reconcile the week. For tighter operations, it supports scale-ready precision, Toast/Square/CSV imports, variance by bottle/station/shift/category, recipe costing, smart orders, receiving, par alerts, barcode scanning, mobile counting, and multi-venue support. It is GPLv3 open source and runs locally.
- Tags: bar-inventory, restaurant-inventory, inventory-management, open-source, pos-integration, beverage-costing, liquor-inventory

### 4. OpenSourceAlternative.to

Process:
1. Go to `https://www.opensourcealternative.to/submit`.
2. Choose free waitlist unless 48-hour review is worth the $29.

Package:
- Your email: rbjpholdings@gmail.com
- Website of open source alternative: https://opensourcebarware.com/
- Name of open source alternative: Open Source Barware
- Repository: https://github.com/RichardBJamison/open-source-barware
- Proprietary software website: https://www.wisk.ai/
- Name of proprietary software: WISK
- Alternative angle: A free GPLv3 alternative for bar inventory workflows, with local/laptop operation, voice/walk counts, tenths, POS import, variance, recipe costing, smart orders, receiving, and no subscription.

Repeat later against:
- BevSpot: https://bevspot.com/
- Partender: https://partender.com/
- Craftable: https://craftable.com/
- MarketMan: https://www.marketman.com/

### 5. SaaSHub

Process:
1. Go to `https://www.saashub.com/submit/list`.
2. Register/login if prompted.

Package:
- Product: Open Source Barware
- URL: https://opensourcebarware.com/free-bar-inventory-software
- Category: Inventory Management
- Pricing: Free forever / GPLv3 open source
- Description: Open Source Barware is a free, open-source bar inventory system for operators. It runs locally, requires no account, and supports voice/walk counting, tenths, scale-ready precision, Toast/Square/CSV imports, variance by bottle/station/shift/category, recipe costing, smart orders, receiving, par alerts, barcode scanning, mobile counting, and multi-venue workflows.
- Alternatives / competitors: WISK, BevSpot, Partender, Backbar, Bar-i, MarketMan, Craftable
- Tags: inventory management, bar inventory, restaurant software, open source, free software, POS integration

### 6. G2 Profile

Process:
1. Go to `https://sell.g2.com/create-a-profile`.
2. Request a new product profile, then claim it after approval.

Package:
- Product name: Open Source Barware
- Vendor/company: Open Source Barware
- Website: https://opensourcebarware.com/
- Category suggestions: Inventory Control, Restaurant Management, Bar POS / Foodservice Management, Business Management
- Short description: Free, open-source bar inventory system for local counts, POS import, variance, recipe costing, ordering, receiving, and multi-venue support.
- Long description: Open Source Barware is a GPLv3, free-forever bar inventory system built for working bars and restaurants. It supports simple voice or walk-based counts for the average bartender, tenths counting, scale-ready precision, POS imports from Toast, Square, and CSV, variance by bottle/station/shift/category, recipe costing, smart orders, receiving, par alerts, barcode scanning, mobile counting, and multi-venue operations. It runs locally, keeps data in open formats, and has no subscription, account, or cloud lock-in.
- Contact: rbjpholdings@gmail.com

### 7. Product Hunt

Process:
1. Go to `https://www.producthunt.com/launch`.
2. Submit > New Product.
3. Schedule only after screenshots, 60-second demo, and first comment are ready.

Package:
- Product name: Open Source Barware
- Tagline: Free open-source bar inventory for real operators.
- Website: https://opensourcebarware.com/
- Description: Count the bar by walking it, voice or typed. Track tenths, scale-ready counts, POS imports, variance, recipes, orders, receiving, and multi-venue workflows. GPLv3, local-first, and free forever.
- Topics: Open Source, Productivity, Operations, Small Business, Food & Drink, Developer Tools
- Founder first comment draft:
  I built Open Source Barware because bar inventory is still too often a clipboard, an old spreadsheet, and a monthly SaaS bill. This is a GPLv3, local-first inventory system for bars: walk the room, count by tenths, import POS data, track variance, build orders, receive product, and keep your own data. It is free forever because the trade needs tools that do not meter basic operating work. I would love feedback from operators, bartenders, and open-source folks.

## Community Drafts

### Hacker News Show HN

Title:
Show HN: Open Source Barware – free GPLv3 inventory software for bars

URL:
https://opensourcebarware.com/

First comment:
I built this after seeing how much bar inventory still depends on clipboards, brittle spreadsheets, and paid SaaS tools. Open Source Barware is GPLv3 and free forever. It starts with simple walk/voice counts and tenths, then scales into POS imports, variance by bottle/station/shift/category, recipe costing, smart orders, receiving, par alerts, barcode scanning, mobile counting, and multi-venue support. It runs locally and keeps data in open formats. Feedback on the open-source packaging, local-first architecture, and operator workflow is welcome.

### Reddit / Bar Operator Community

Title:
Free open-source bar inventory system: looking for operator feedback

Post:
I built a free GPLv3 bar inventory system around the way real bars count: walking the room, voice or typed notes, tenths, scale-ready precision, POS imports, variance, recipe costing, smart orders, receiving, and par alerts. No subscription, no account, no cloud lock-in.

I am not trying to sell anything. I am looking for bartender/bar manager feedback: what would make this useful during a real close or weekly count? Setup guide is here: https://opensourcebarware.com/blog/free-inventory-system-guide

## Monitoring

Check weekly for 4 weeks:
- GSC: impressions/clicks for `free inventory system`, `free bar inventory system`, `best bar inventory system`, `free inventory system for bars`, `open source bar inventory`.
- GSC: pages indexed vs submitted for `/blog/*`, `/the-process`, `/free-bar-inventory-software`.
- Bing Webmaster: URL submission status and IndexNow discovery.
- GA4: organic landing pages for `/free-bar-inventory-software`, `/the-process`, `/blog/*`.
- Referral traffic: RestaurantIMS, SourceForge, AlternativeTo, OpenSourceAlternative, Product Hunt, HN.

## Content Follow-Ups

Highest-value next posts:
- Open Source Barware vs WISK: Free/Open Source vs Paid Bar Inventory
- Free Liquor Inventory Spreadsheet vs Free Bar Inventory System
- Best Bar Inventory System for Independent Bars
- How to Track Bottle Variance by Shift
- Toast POS Inventory Export to Variance Workflow
- Square POS Bar Inventory Workflow

AI-search quick wins:
- Deploy the cleaned `llms.txt`.
- Add `/blog/feed.xml` to footer or blog metadata where already not visible.
- Add a concise `FAQPage` section to `/free-bar-inventory-software` with direct answers for target keywords.
- Add a comparison table on `/free-bar-inventory-software`: free/local/open-source vs cloud/subscription tools.
- Keep schema current: SoftwareApplication, Article, HowTo, VideoObject, ImageObject.

## Nexus Logging Completed

Logged:
- Started SEO directory submission research.
- Patched public `llms.txt` stale brand reference.
- Patched public GitHub repository URL typo.
- Submitted Open Source Barware to RestaurantIMS.

Use this pattern for every next action:

```bash
python3 ~/Me-Nexus/scripts/coordination_append.py --agent CODEX --project opensourcebarware --action "Prepared/submitted to [directory name]" --status in-progress --verification partial --notes "Details..."
```
