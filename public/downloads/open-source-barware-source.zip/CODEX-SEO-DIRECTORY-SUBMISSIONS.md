# Codex SEO: Directory Submissions + Indexing Push
**Project:** opensourcebarware  
**Site:** https://opensourcebarware.com  
**Date:** 2026-07-08  
**Status:** New blog (4 posts 2026-07-08), updated /the-process wording ("Simple to start. Industrial strength..."), non-visual SEO (alts, VideoObject/ImageObject/HowTo/Article/SoftwareApplication schema, metadata for "free bar inventory system" + "best bar inventory system"), sitemap expanded, RSS feed, IndexNow updated + pinged.

**Nothing has been sent to industry directories yet. No manual GSC/Bing sitemap re-submits or URL inspections for the new work yet.**  
User wants Codex to **research, prepare, and execute submissions on user's behalf** (generate ready copy, form data, emails, exact steps) and drive indexing of **all the new work**.

---

## New Work to Index / Promote (exact URLs + positioning)

Base: https://opensourcebarware.com

Key pages (all in live sitemap.xml):
- https://opensourcebarware.com/ (home)
- https://opensourcebarware.com/the-process — "One Chrome-side program. Simple to start. Industrial strength when you need it." Starts easy/fast for average bartender (voice or walk), scales + pinpoint measurements built-in, full bells & whistles (mobile counting, POS import, variance, smart orders, multi-venue, recipes/costing, receiving). Caterpillar to butterfly. Scalable from 1 bar to many.
- https://opensourcebarware.com/free-bar-inventory-software — primary keyword landing
- https://opensourcebarware.com/download + /downloads
- https://opensourcebarware.com/blog — hub
- https://opensourcebarware.com/blog/free-inventory-system-guide — "Free Inventory System for Bars: Setup in One Night"
- https://opensourcebarware.com/blog/best-free-bar-inventory-system — "Why Open Source Barware is the Best Free Bar Inventory System"
- https://opensourcebarware.com/blog/variance-tracking-that-works
- https://opensourcebarware.com/blog/pos-integration-free-inventory — "POS Integration in a Free Inventory System — Why It Matters More Than You Think"
- https://opensourcebarware.com/blog/feed.xml (RSS + Article schema)
- Supporting: /about, /resources, /manifesto, /liquor-inventory, /wine-inventory, /open-source-compliance

**Core claims to use verbatim or close (from live pages):**
- Free. Open source (GPLv3). 100% free to the world. No subscription. Runs on your laptop.
- "Absolutely free. 100% free to the world. Come try it."
- Simple to start for the average bartender (voice notes/walks, tenths counting) yet industrial-strength with scales/pinpoint measurements, full feature set, and improving daily.
- One Chrome-side program. Built by a bartender/operator. Forged in Cleveland, Ohio.
- Data stays yours. Open formats. Real operator workflows (not generic SaaS).

**Keywords to target:** free bar inventory system, best bar inventory system, free inventory system for bars, free bar inventory software, open source bar inventory.

---

## Indexing Actions (do these first or in parallel)

1. **IndexNow** — Already updated script + executed (both endpoints 200 OK on 2026-07-08). Re-run after future deploys:
   ```
   cd "/Users/macbook15/Documents/New project/open-source-barware"
   node scripts/ping-indexnow.mjs
   ```
   (Script now includes all blog posts + feed.)

2. **Sitemap** — Live at https://opensourcebarware.com/sitemap.xml (15+ URLs, lastmod today). Confirm in GSC/Bing.

3. **Google Search Console (GSC)**:
   - Property: opensourcebarware.com (domain verified via Cloudflare).
   - Submit sitemap: https://opensourcebarware.com/sitemap.xml
   - URL Inspection + "Request Indexing" for the new/high-value ones:
     - /the-process
     - /blog
     - /blog/free-inventory-system-guide
     - /blog/best-free-bar-inventory-system
     - /free-bar-inventory-software
     - /blog/feed.xml (and individual posts)
   - Check Coverage report for "Crawled - currently not indexed" or "Discovered - currently not indexed". Report findings.

4. **Bing Webmaster Tools**:
   - Submit sitemap.
   - Submit URLs individually for the blog + the-process.
   - Use IndexNow (already pinged).

5. **Other**:
   - Confirm https://opensourcebarware.com/robots.txt and /llms.txt are clean and reference the content.
   - After submissions, monitor organic sessions in GA4 (G-DQJKBWMM8H) and COMMS snapshot.

**Log every meaningful step** with:
`python3 ~/Me-Nexus/scripts/coordination_append.py --agent CODEX --project opensourcebarware --action "..." --status in-progress --verification passed --notes "..."`

---

## Starter Directory / Listing Targets (research fresh — expand this list)

Prioritize **quality over quantity**. Focus on open-source, hospitality/bar, free software, inventory, and small-business software directories that accept free tools. Many old lists are dead — verify live forms.

High-priority (research exact current submission URL/method):
1. **FSF Free Software Directory** (https://directory.fsf.org/) — Perfect match (GPLv3, truly free, no subscription). Look for wiki edit or "add entry" process. Attend or note Friday IRC meetup if active. Prepare full package: name, description, license, category (Inventory, Bar management), homepage, download link (GitHub + direct zips), keywords.
2. **restaurantinventorymanagementsoftware.com** (and similar comparison sites) — Independent bar/restaurant inventory software directory/comparison. They list 80+ tools. Contact/submit for inclusion (no paid placement per their copy). Use the "best free" positioning + comparison points from our blog.
3. **SourceForge** — Classic open source listing + downloads. Create project or update if mirror exists. Categories: Office/Business > Inventory, etc.
4. **AlternativeTo** — "Open Source Barware" alternatives to paid bar inventory (WISK, BevSpot, etc.). High visibility for "free" searches.
5. **SaaS / software directories from 2026 lists** (from research: blastra.io, position.digital 260+ list, saashunt, etc.):
   - Curated free/open-friendly ones (avoid heavy paid-only).
   - G2, Capterra, GetApp, Software Advice — check if free tier listings accepted or "community" entry.
6. **GitHub Awesome lists** — e.g. awesome-selfhosted, or hospitality/pos related. Open PR with short description + link.
7. **Product Hunt** — If not launched yet or for re-feature. Use the "free to the world" angle + bartender story.
8. **Hospitality / bar specific**:
   - Bar & Restaurant industry resource pages, state associations, Nightclub & Bar media.
   - Search "bar management resources list" "free bar tools directory".
   - POS partner directories (Toast, Square) — they sometimes list complementary free tools.
9. **General high-DR**:
   - Other entries from recent "260+ SaaS Directories" roundups that accept free/open source.
   - IndieHackers listings, Launching Next, etc.

**Instructions for each target:**
- Visit page, screenshot or note the form fields.
- Craft:
  - Title / Name
  - Short description (1 sentence, keyword front-loaded)
  - Long description (80-150 words, use the "simple for average bartender + industrial strength + scales + free forever" story + specific features from the-process + blog excerpts)
  - Categories / tags
  - URL, download/GitHub links
  - Contact: rbjpholdings@gmail.com (or the one on site)
  - Owner / location: Richard B. Jamison, Cleveland, Ohio. Built from real bar ops.
- Output **ready-to-submit text blocks** + exact URL of the submission form.
- If email-based: draft professional email.
- Prioritize 10-15 solid ones first. Quality citations > spam.

**Do fresh searches every time:**
- "submit bar inventory software" 
- "hospitality software directory"
- "free open source inventory tool directory"
- "bar management resources" "add your tool"
- Check dates — only active 2026 directories.

After prep, present a prioritized table or list with status (researched / copy ready / submitted / verified live).

---

## Full Prompt to Paste to Codex (copy from here)

```
You are Codex. Your task is to research, prepare, and drive submissions + indexing for Open Source Barware on behalf of Richard (rbjpholdings@gmail.com). Project ID in Nexus: opensourcebarware.

Site: https://opensourcebarware.com
Repo (for reference): /Users/macbook15/Documents/New project/open-source-barware
GA4: G-DQJKBWMM8H

Key facts (use these exact angles, no hype, operator voice):
- 100% free and open source (GPLv3). "Absolutely free. 100% free to the world. Come try it."
- One Chrome-side program. "Simple to start. Industrial strength when you need it."
- Starts dead simple for the average bartender: voice notes or walk the bar, tenths counting, fast entry. No learning curve, no cloud, runs locally.
- Industrial strength built in: scales for pinpoint measurements, mobile counting, POS import (Toast/Square/CSV), variance tracking (bottle/station/shift/category), recipes & costing, smart orders, multi-venue support, receiving, par alerts. Getting better daily.
- Built by a real bartender/operator in Cleveland. Data is yours in open formats.
- New authoritative content just published (2026-07-08): 4 in-depth blog posts + refreshed /the-process page explaining the dual nature (easy start + full power).

New pages that must be indexed and listed everywhere:
- https://opensourcebarware.com/the-process (updated wording)
- https://opensourcebarware.com/blog (and the 4 posts: free-inventory-system-guide, best-free-bar-inventory-system, variance-tracking-that-works, pos-integration-free-inventory)
- https://opensourcebarware.com/free-bar-inventory-software
- Full sitemap: https://opensourcebarware.com/sitemap.xml (15+ URLs)
- RSS: https://opensourcebarware.com/blog/feed.xml

Your mission:
1. Start with indexing actions:
   - Confirm sitemap live and complete.
   - Re-run (or confirm) IndexNow if needed: node scripts/ping-indexnow.mjs
   - Give Richard precise step-by-step + direct links for Google Search Console: submit sitemap + request indexing on the new blog + the-process + free-bar-inventory-software pages. Same for Bing Webmaster.
   - Report current indexed count vs sitemap (use your search or note user to check GSC).

2. Research (use web_search / browse tools aggressively):
   - Current active directories, listing sites, and "submit your software" pages for:
     - Open source / free software (start with FSF Free Software Directory)
     - Bar / restaurant / hospitality inventory and management tools
     - General SaaS / software directories that accept free tools
   - Produce a fresh, vetted, prioritized list (10-20). Discard dead links. Note submission method for each (form, email, PR, wiki).

3. For every target:
   - Prepare complete submission package:
     - Exact form values or email body (title, description short + long, categories, tags, keywords, links, contact).
     - Use the positioning above. Pull real excerpts from /the-process and the blog posts.
     - Make descriptions authoritative and specific (voice walks, tenths, scales/pinpoint, POS, variance, multi-venue, free forever).
   - If possible, draft outreach notes or "why list us" one-pager.
   - Output everything ready for Richard (or you) to submit immediately. Number them.

4. Execution:
   - Where you can fill/submit directly (or simulate with details), do the prep work.
   - For forms that require human click, give copy-paste blocks + URL + instructions.
   - After prep or submit, log progress in Nexus using the coordination script exactly:
     python3 ~/Me-Nexus/scripts/coordination_append.py --agent CODEX --project opensourcebarware --action "Prepared/submitted to [directory name]" --status in-progress --verification partial --notes "Details..."
   - Update this file or create follow-up notes.

5. Deliverables format:
   - Prioritized table: Directory | URL | Submission method | Status | Ready copy (or link to block)
   - Separate "Indexing Status" section with GSC/Bing steps + current observations.
   - Any suggested follow-ups (press, outreach emails, link building from the lists).

Rules:
- BLUF. Direct. No fluff.
- Quality only. No spam directories.
- Stay true to the site's voice: serious cocktail operator, not marketing fluff.
- Preserve "free forever" and the simple-start + industrial-strength duality.
- If you need Richard's ranking report or GSC access details, ask once.
- After major batch, suggest next deploy or sitemap refresh if pages changed.

Begin by confirming the sitemap contents and running a fresh search for "free software directory submit" + "bar inventory software directory" + "restaurant management software directory 2026". Then produce the first 5-8 high-quality submission packages.

Report back with status after each major step.
```

---

## Next Steps After Codex Runs

- User pastes prompt to Codex.
- Codex returns packages + logs via coordination script.
- User (or Codex) submits the top ones.
- Re-ping IndexNow + request indexing in GSC for any accepted listings / new backlinks.
- Track in GA4 + report in next handoff.
- Add successful listings to /resources or a "mentioned in" section later if desired.

**Files touched in this prep:** scripts/ping-indexnow.mjs (updated + executed), this CODEX-SEO-DIRECTORY-SUBMISSIONS.md, coordination ledger entry.

Run the ping again after any future content or blog additions.
```

Now give Codex the prompt above (or the whole file). Nothing else is needed on-page for this request.